//Feito por: Fabio Ganum Filho - 15450803

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fornecidas.c"
#include "registro.h"
#include "traducao.h"
#include "busca.h"

int main(void) {
    int numFunc, n;

    if (scanf("%d", &numFunc) != 1) {
        return 0;
    }

    switch (numFunc) {
        case 1: {
            char *nomeArquivo = (char *) calloc(50, sizeof(char));
            char *nomeSaida = (char *) calloc(50, sizeof(char));
            scanf(" %49s", nomeArquivo);
            scanf(" %49s", nomeSaida);

            FILE *file = fopen(nomeArquivo, "r");
            FILE *bin = fopen(nomeSaida, "wb+");
            if (file == NULL || bin == NULL) {
                printf("Falha no processamento do arquivo.\n");
                free(nomeArquivo);
                free(nomeSaida);
                if (file != NULL) {
                    fclose(file);
                }
                if (bin != NULL) {
                    fclose(bin);
                }
                return 0;
            }

            Cabecalho_s cab = criarCab();
            escreverCab(cab, bin);
            transcrever(file, bin, &cab);
            fecharCab(&cab);
            escreverCab(cab, bin);

            fclose(bin);
            fclose(file);
            BinarioNaTela(nomeSaida);
            free(nomeArquivo);
            free(nomeSaida);
            break;
        }

        case 2: {
            char *nomeArquivo = (char *) calloc(50, sizeof(char));
            scanf(" %49s", nomeArquivo);
            FILE *bin = fopen(nomeArquivo, "rb");
            if (bin == NULL) {
                printf("Falha no processamento do arquivo.\n");
                free(nomeArquivo);
                return 0;
            }
            escrever(bin);
            fclose(bin);
            free(nomeArquivo);
            break;
        }

        case 3: {
            char *nomeArquivo = (char *) calloc(50, sizeof(char));
            scanf(" %49s", nomeArquivo);
            FILE *bin = fopen(nomeArquivo, "rb");
            if (bin == NULL) {
                printf("Falha no processamento do arquivo.\n");
                free(nomeArquivo);
                return 0;
            }

            scanf(" %d", &n);
            for (int i = 0; i < n; i++) {
                busca(bin);
                printf("\n");
            }

            fclose(bin);
            free(nomeArquivo);
            break;
        }

        case 4: {
            char *nomeArquivo = (char *) calloc(50, sizeof(char));
            scanf(" %49s", nomeArquivo);
            FILE *bin = fopen(nomeArquivo, "rb+");
            if (bin == NULL) {
                printf("Falha no processamento do arquivo.\n");
                free(nomeArquivo);
                return 0;
            }

            statusCab(nomeArquivo, 0);
            scanf(" %d", &n);
            for (int i = 0; i < n; i++) {
                exclusao(bin);
            }
            statusCab(nomeArquivo, 1);

            fclose(bin);
            BinarioNaTela(nomeArquivo);
            free(nomeArquivo);
            break;
        }

        case 5: {
            char *nomeArquivo = (char *) calloc(50, sizeof(char));
            scanf(" %49s", nomeArquivo);
            FILE *bin = fopen(nomeArquivo, "rb+");
            if (bin == NULL) {
                printf("Falha no processamento do arquivo.\n");
                free(nomeArquivo);
                return 0;
            }

            statusCab(nomeArquivo, 0);
            insercao(bin);
            statusCab(nomeArquivo, 1);

            fclose(bin);
            BinarioNaTela(nomeArquivo);
            free(nomeArquivo);
            break;
        }

        case 6: {
            char *nomeArquivo = (char *) calloc(50, sizeof(char));
            scanf(" %49s", nomeArquivo);
            FILE *bin = fopen(nomeArquivo, "rb+");
            if (bin == NULL) {
                printf("Falha no processamento do arquivo.\n");
                free(nomeArquivo);
                return 0;
            }

            statusCab(nomeArquivo, 0);
            atualizacao(bin);
            statusCab(nomeArquivo, 1);

            fclose(bin);
            BinarioNaTela(nomeArquivo);
            free(nomeArquivo);
            break;
        }

        default:
            break;
    }

    return 0;
}
