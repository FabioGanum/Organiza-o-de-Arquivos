//Feito por: Fabio Ganum Filho - 15450803
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "registro.h"
#include "traducao.h"

static int nomeJaExiste(char **vetor, int numEst, const char *nome) {
    for (int i = 0; i < numEst; i++) {
        if (strcmp(nome, vetor[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

static int parJaExiste(int *codEst, int *codProx, int qtd, int atualCodEst, int atualCodProx) {
    for (int i = 0; i < qtd; i++) {
        if (codEst[i] == atualCodEst && codProx[i] == atualCodProx) {
            return 1;
        }
    }
    return 0;
}

void escreverReg(FILE *file, Registro_s regs) {
    fwrite(&regs.removido, sizeof(char), 1, file);
    fwrite(&regs.proximo, sizeof(int), 1, file);
    fwrite(&regs.CodEstacao, sizeof(int), 1, file);
    fwrite(&regs.CodLinha, sizeof(int), 1, file);
    fwrite(&regs.CodProxEst, sizeof(int), 1, file);
    fwrite(&regs.distProxEstacao, sizeof(int), 1, file);
    fwrite(&regs.codLinhaIntegra, sizeof(int), 1, file);
    fwrite(&regs.codEstIntegra, sizeof(int), 1, file);
    fwrite(&regs.tamNomeEstacao, sizeof(int), 1, file);
    if (regs.tamNomeEstacao > 0) {
        fwrite(regs.NomeEstacao, sizeof(char), regs.tamNomeEstacao, file);
    }
    fwrite(&regs.tamNomeLinha, sizeof(int), 1, file);
    if (regs.tamNomeLinha > 0) {
        fwrite(regs.NomeLinha, sizeof(char), regs.tamNomeLinha, file);
    }
    for (int i = regs.tamNomeLinha + regs.tamNomeEstacao; i < 43; i++) {
        fwrite("$", sizeof(char), 1, file);
    }
}

void liberarReg(Registro_s *reg) {
    if (reg->NomeEstacao != NULL) {
        free(reg->NomeEstacao);
        reg->NomeEstacao = NULL;
    }
    if (reg->NomeLinha != NULL) {
        free(reg->NomeLinha);
        reg->NomeLinha = NULL;
    }
}

void lerLinha(char *linha, struct registro *reg) {
    char *ptr = linha;
    char *proxima_virgula;

    linha[strcspn(linha, "\r\n")] = '\0';

    reg->NomeEstacao = NULL;
    reg->NomeLinha = NULL;
    reg->tamNomeEstacao = 0;
    reg->tamNomeLinha = 0;

    for (int i = 0; i < 8; i++) {
        proxima_virgula = strchr(ptr, ',');
        if (proxima_virgula != NULL) {
            *proxima_virgula = '\0';
        }

        switch (i) {
            case 0:
                reg->CodEstacao = (strlen(ptr) == 0) ? -1 : atoi(ptr);
                break;
            case 1:
                reg->NomeEstacao = strdup(ptr);
                reg->tamNomeEstacao = (int)strlen(ptr);
                break;
            case 2:
                reg->CodLinha = (strlen(ptr) == 0) ? -1 : atoi(ptr);
                break;
            case 3:
                reg->NomeLinha = strdup(ptr);
                reg->tamNomeLinha = (int)strlen(ptr);
                break;
            case 4:
                reg->CodProxEst = (strlen(ptr) == 0) ? -1 : atoi(ptr);
                break;
            case 5:
                reg->distProxEstacao = (strlen(ptr) == 0) ? -1 : atoi(ptr);
                break;
            case 6:
                reg->codLinhaIntegra = (strlen(ptr) == 0) ? -1 : atoi(ptr);
                break;
            case 7:
                reg->codEstIntegra = (strlen(ptr) == 0) ? -1 : atoi(ptr);
                break;
        }

        if (proxima_virgula != NULL) {
            ptr = proxima_virgula + 1;
        } else {
            break;
        }
    }
}

void transcrever(FILE *base, FILE *bin, Cabecalho_s *cab) {
    char linha[200];
    fgets(linha, 200, base);

    char **estacoes = (char **) malloc(201 * sizeof(char *));
    for (int i = 0; i < 201; i++) {
        estacoes[i] = (char *) calloc(100, sizeof(char));
    }
    int numEst = 0;

    while (fgets(linha, 200, base) != NULL) {
        Registro_s novoReg;
        lerLinha(linha, &novoReg);
        novoReg.removido = '0';
        novoReg.proximo = -1;

        escreverReg(bin, novoReg);

        if (!nomeJaExiste(estacoes, numEst, novoReg.NomeEstacao)) {
            cab->nroEstacoes++;
            strcpy(estacoes[numEst], novoReg.NomeEstacao);
            numEst++;
        }

        if (novoReg.CodProxEst != -1) {
            cab->nroParesEstacoes++;
        }
        cab->proxRRN++;
        liberarReg(&novoReg);
    }

    for (int i = 0; i < 201; i++) {
        free(estacoes[i]);
    }
    free(estacoes);
}

Cabecalho_s criarCab(void) {
    Cabecalho_s cabecalho;
    cabecalho.status = '0';
    cabecalho.topo = -1;
    cabecalho.proxRRN = 0;
    cabecalho.nroEstacoes = 0;
    cabecalho.nroParesEstacoes = 0;
    return cabecalho;
}

void fecharCab(Cabecalho_s *cab) {
    cab->status = '1';
}

void abrirCab(Cabecalho_s *cab) {
    cab->status = '0';
}

void escreverCab(Cabecalho_s cab, FILE *file) {
    rewind(file);
    fwrite(&cab.status, sizeof(char), 1, file);
    fwrite(&cab.topo, sizeof(int), 1, file);
    fwrite(&cab.proxRRN, sizeof(int), 1, file);
    fwrite(&cab.nroEstacoes, sizeof(int), 1, file);
    fwrite(&cab.nroParesEstacoes, sizeof(int), 1, file);
}

void statusCab(char *nomeArq, int status) {
    FILE *fp = fopen(nomeArq, "rb+");
    if (fp == NULL) {
        return;
    }

    Cabecalho_s cab = lerCab(fp);
    cab.status = (status == 0) ? '0' : '1';
    escreverCab(cab, fp);
    fclose(fp);
}

Cabecalho_s lerCab(FILE *fp) {
    Cabecalho_s cab;
    long int posAtual = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    fread(&cab.status, sizeof(char), 1, fp);
    fread(&cab.topo, sizeof(int), 1, fp);
    fread(&cab.proxRRN, sizeof(int), 1, fp);
    fread(&cab.nroEstacoes, sizeof(int), 1, fp);
    fread(&cab.nroParesEstacoes, sizeof(int), 1, fp);
    fseek(fp, posAtual, SEEK_SET);
    return cab;
}

void recalcularCabecalho(FILE *bin) {
    Cabecalho_s cab = lerCab(bin);
    int capacidade = (cab.proxRRN > 0) ? cab.proxRRN : 1;

    char **estacoes = (char **) malloc(capacidade * sizeof(char *));
    int *codEst = (int *) malloc(capacidade * sizeof(int));
    int *codProx = (int *) malloc(capacidade * sizeof(int));
    int qtdEstacoes = 0;
    int qtdPares = 0;

    fseek(bin, 17, SEEK_SET);

    Registro_s reg;
    while (fread(&reg.removido, sizeof(char), 1, bin) == 1) {
        lerReg(bin, &reg);

        if (reg.removido == '0') {
            if (!nomeJaExiste(estacoes, qtdEstacoes, reg.NomeEstacao)) {
                estacoes[qtdEstacoes] = strdup(reg.NomeEstacao);
                qtdEstacoes++;
            }

            if (reg.CodProxEst != -1 && !parJaExiste(codEst, codProx, qtdPares, reg.CodEstacao, reg.CodProxEst)) {
                codEst[qtdPares] = reg.CodEstacao;
                codProx[qtdPares] = reg.CodProxEst;
                qtdPares++;
            }
        }

        liberarReg(&reg);
    }

    cab.nroEstacoes = qtdEstacoes;
    cab.nroParesEstacoes = qtdPares;
    escreverCab(cab, bin);

    for (int i = 0; i < qtdEstacoes; i++) {
        free(estacoes[i]);
    }
    free(estacoes);
    free(codEst);
    free(codProx);
    rewind(bin);
}
