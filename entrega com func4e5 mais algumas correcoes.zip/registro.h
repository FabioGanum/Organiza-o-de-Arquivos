#ifndef REGISTRO_H
#define REGISTRO_H
#include <stdio.h>

typedef struct registro Registro_s;
typedef struct cabecalho Cabecalho_s;

struct registro {
    char removido;
    int proximo;
    int CodEstacao;
    int CodLinha;
    int CodProxEst;
    int distProxEstacao;
    int codLinhaIntegra;
    int codEstIntegra;
    int tamNomeEstacao;
    char *NomeEstacao;
    int tamNomeLinha;
    char *NomeLinha;
};

struct cabecalho {
    char status;
    int topo;
    int proxRRN;
    int nroEstacoes;
    int nroParesEstacoes;
};

void escreverReg(FILE *file, Registro_s regs);
void liberarReg(Registro_s *reg);
void transcrever(FILE *base, FILE *bin, Cabecalho_s *cab);
void recalcularCabecalho(FILE *bin);

Cabecalho_s criarCab(void);
void escreverCab(Cabecalho_s cab, FILE *file);
void fecharCab(Cabecalho_s *cab);
void abrirCab(Cabecalho_s *cab);
void statusCab(char *nomeArq, int status);
Cabecalho_s lerCab(FILE *fp);

#endif
