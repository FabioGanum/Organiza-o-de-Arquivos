//Feito por: Fabio Ganum Filho - 15450803
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "traducao.h"

static void imprimirInteiroOuNulo(int valor) {
    if (valor == -1) {
        printf("NULO");
    } else {
        printf("%d", valor);
    }
}

static void imprimirStringOuNulo(const char *str, int tamanho) {
    if (tamanho == 0) {
        printf("NULO");
    } else {
        printf("%s", str);
    }
}

void escrever(FILE *bin) {
    Registro_s reg;
    int exibiu = 0;

    if (bin == NULL) {
        printf("Falha no processamento do arquivo.\n");
        return;
    }

    fseek(bin, 17, SEEK_SET);

    while (fread(&reg.removido, sizeof(char), 1, bin) == 1) {
        lerReg(bin, &reg);

        if (reg.removido == '0') {
            printarReg(bin, reg);
            exibiu = 1;
        }

        free(reg.NomeEstacao);
        free(reg.NomeLinha);
    }

    if (!exibiu) {
        printf("Registro inexistente.\n");
    }
}

void lerReg(FILE *bin, Registro_s *reg) {
    reg->NomeEstacao = NULL;
    reg->NomeLinha = NULL;

    fread(&reg->proximo, sizeof(int), 1, bin);
    fread(&reg->CodEstacao, sizeof(int), 1, bin);
    fread(&reg->CodLinha, sizeof(int), 1, bin);
    fread(&reg->CodProxEst, sizeof(int), 1, bin);
    fread(&reg->distProxEstacao, sizeof(int), 1, bin);
    fread(&reg->codLinhaIntegra, sizeof(int), 1, bin);
    fread(&reg->codEstIntegra, sizeof(int), 1, bin);
    fread(&reg->tamNomeEstacao, sizeof(int), 1, bin);

    reg->NomeEstacao = (char *) malloc((size_t) reg->tamNomeEstacao + 1);
    if (reg->tamNomeEstacao > 0) {
        fread(reg->NomeEstacao, sizeof(char), reg->tamNomeEstacao, bin);
    }
    reg->NomeEstacao[reg->tamNomeEstacao] = '\0';

    fread(&reg->tamNomeLinha, sizeof(int), 1, bin);
    reg->NomeLinha = (char *) malloc((size_t) reg->tamNomeLinha + 1);
    if (reg->tamNomeLinha > 0) {
        fread(reg->NomeLinha, sizeof(char), reg->tamNomeLinha, bin);
    }
    reg->NomeLinha[reg->tamNomeLinha] = '\0';

    for (int j = reg->tamNomeEstacao + reg->tamNomeLinha; j < 43; j++) {
        char lixo;
        fread(&lixo, sizeof(char), 1, bin);
    }
}

void printarReg(FILE *bin, Registro_s reg) {
    (void) bin;

    imprimirInteiroOuNulo(reg.CodEstacao);
    printf(" ");
    imprimirStringOuNulo(reg.NomeEstacao, reg.tamNomeEstacao);
    printf(" ");
    imprimirInteiroOuNulo(reg.CodLinha);
    printf(" ");
    imprimirStringOuNulo(reg.NomeLinha, reg.tamNomeLinha);
    printf(" ");
    imprimirInteiroOuNulo(reg.CodProxEst);
    printf(" ");
    imprimirInteiroOuNulo(reg.distProxEstacao);
    printf(" ");
    imprimirInteiroOuNulo(reg.codLinhaIntegra);
    printf(" ");
    imprimirInteiroOuNulo(reg.codEstIntegra);
    printf("\n");
}
