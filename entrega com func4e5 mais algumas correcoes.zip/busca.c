//Feito por: Fabio Ganum Filho - 15450803
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "busca.h"
#include "registro.h"
#include "traducao.h"
extern void ScanQuoteString(char *str);

static int ehCampoString(const char *nomeCampo) {
    return strcmp(nomeCampo, "nomeLinha") == 0 || strcmp(nomeCampo, "nomeEstacao") == 0;
}

static int lerInteiroOuNulo(const char *valor) {
    if (strcmp(valor, "NULO") == 0) {
        return -1;
    }
    return atoi(valor);
}

static void lerValorCampo(const char *nomeCampo, char *valor) {
    if (ehCampoString(nomeCampo)) {
        ScanQuoteString(valor);
        if (strlen(valor) == 0) {
            strcpy(valor, "NULO");
        }
    } else {
        scanf(" %99s", valor);
    }
}

static void lerParametros(Parametros_s *par, int qtd) {
    for (int i = 0; i < qtd; i++) {
        scanf(" %29s", par[i].nome);
        lerValorCampo(par[i].nome, par[i].valor);
    }
}

static void alterarString(char **campo, int *tamCampo, const char *valor) {
    free(*campo);

    if (strcmp(valor, "NULO") == 0) {
        *campo = strdup("");
        *tamCampo = 0;
    } else {
        *campo = strdup(valor);
        *tamCampo = (int) strlen(valor);
    }
}

int comparacoes(FILE *bin, Registro_s reg, Parametros_s *par, int m) {
    (void) bin;

    if (m < 0) {
        return 0;
    }

    if (strcmp(par[m].nome, "codEstacao") == 0) {
        if (reg.CodEstacao == lerInteiroOuNulo(par[m].valor)) {
            return comparacoes(bin, reg, par, m - 1);
        }
        return 1;
    }

    if (strcmp(par[m].nome, "codLinha") == 0) {
        if (reg.CodLinha == lerInteiroOuNulo(par[m].valor)) {
            return comparacoes(bin, reg, par, m - 1);
        }
        return 1;
    }

    if (strcmp(par[m].nome, "codProxEstacao") == 0) {
        if (reg.CodProxEst == lerInteiroOuNulo(par[m].valor)) {
            return comparacoes(bin, reg, par, m - 1);
        }
        return 1;
    }

    if (strcmp(par[m].nome, "distProxEstacao") == 0) {
        if (reg.distProxEstacao == lerInteiroOuNulo(par[m].valor)) {
            return comparacoes(bin, reg, par, m - 1);
        }
        return 1;
    }

    if (strcmp(par[m].nome, "codLinhaIntegra") == 0) {
        if (reg.codLinhaIntegra == lerInteiroOuNulo(par[m].valor)) {
            return comparacoes(bin, reg, par, m - 1);
        }
        return 1;
    }

    if (strcmp(par[m].nome, "codEstIntegra") == 0) {
        if (reg.codEstIntegra == lerInteiroOuNulo(par[m].valor)) {
            return comparacoes(bin, reg, par, m - 1);
        }
        return 1;
    }

    if (strcmp(par[m].nome, "nomeLinha") == 0) {
        if ((reg.tamNomeLinha == 0 && strcmp(par[m].valor, "NULO") == 0) ||
            (reg.tamNomeLinha > 0 && strcmp(reg.NomeLinha, par[m].valor) == 0)) {
            return comparacoes(bin, reg, par, m - 1);
        }
        return 1;
    }

    if (strcmp(par[m].nome, "nomeEstacao") == 0) {
        if ((reg.tamNomeEstacao == 0 && strcmp(par[m].valor, "NULO") == 0) ||
            (reg.tamNomeEstacao > 0 && strcmp(reg.NomeEstacao, par[m].valor) == 0)) {
            return comparacoes(bin, reg, par, m - 1);
        }
        return 1;
    }

    return 1;
}

static void lerRegistroInsercao(Registro_s *reg) {
    char buffer[100];

    reg->removido = '0';
    reg->proximo = -1;

    scanf(" %99s", buffer);
    reg->CodEstacao = lerInteiroOuNulo(buffer);

    ScanQuoteString(buffer);
    reg->NomeEstacao = strdup(buffer);
    reg->tamNomeEstacao = (int) strlen(buffer);

    scanf(" %99s", buffer);
    reg->CodLinha = lerInteiroOuNulo(buffer);

    ScanQuoteString(buffer);
    if (strlen(buffer) == 0) {
        reg->NomeLinha = strdup("");
        reg->tamNomeLinha = 0;
    } else {
        reg->NomeLinha = strdup(buffer);
        reg->tamNomeLinha = (int) strlen(buffer);
    }

    scanf(" %99s", buffer);
    reg->CodProxEst = lerInteiroOuNulo(buffer);
    scanf(" %99s", buffer);
    reg->distProxEstacao = lerInteiroOuNulo(buffer);
    scanf(" %99s", buffer);
    reg->codLinhaIntegra = lerInteiroOuNulo(buffer);
    scanf(" %99s", buffer);
    reg->codEstIntegra = lerInteiroOuNulo(buffer);
}

static void aplicarAtualizacoes(Registro_s *reg, Parametros_s *par, int qtd) {
    for (int i = 0; i < qtd; i++) {
        if (strcmp(par[i].nome, "codEstacao") == 0) {
            reg->CodEstacao = lerInteiroOuNulo(par[i].valor);
        } else if (strcmp(par[i].nome, "codLinha") == 0) {
            reg->CodLinha = lerInteiroOuNulo(par[i].valor);
        } else if (strcmp(par[i].nome, "codProxEstacao") == 0) {
            reg->CodProxEst = lerInteiroOuNulo(par[i].valor);
        } else if (strcmp(par[i].nome, "distProxEstacao") == 0) {
            reg->distProxEstacao = lerInteiroOuNulo(par[i].valor);
        } else if (strcmp(par[i].nome, "codLinhaIntegra") == 0) {
            reg->codLinhaIntegra = lerInteiroOuNulo(par[i].valor);
        } else if (strcmp(par[i].nome, "codEstIntegra") == 0) {
            reg->codEstIntegra = lerInteiroOuNulo(par[i].valor);
        } else if (strcmp(par[i].nome, "nomeLinha") == 0) {
            alterarString(&reg->NomeLinha, &reg->tamNomeLinha, par[i].valor);
        } else if (strcmp(par[i].nome, "nomeEstacao") == 0) {
            alterarString(&reg->NomeEstacao, &reg->tamNomeEstacao, par[i].valor);
        }
    }
}

void busca(FILE *bin) {
    int m;
    scanf(" %d", &m);

    fseek(bin, 17, SEEK_SET);

    Parametros_s *par = (Parametros_s *) malloc((size_t) m * sizeof(Parametros_s));
    lerParametros(par, m);

    Registro_s reg;
    int printou = 0;
    while (fread(&reg.removido, sizeof(char), 1, bin) == 1) {
        lerReg(bin, &reg);

        if (reg.removido == '0' && comparacoes(bin, reg, par, m - 1) == 0) {
            printarReg(bin, reg);
            printou++;
        }
        liberarReg(&reg);
    }

    if (printou == 0) {
        printf("Registro inexistente.\n");
    }

    free(par);
    rewind(bin);
}

void exclusao(FILE *bin) {
    int m;
    scanf(" %d", &m);

    fseek(bin, 17, SEEK_SET);

    Parametros_s *par = (Parametros_s *) malloc((size_t) m * sizeof(Parametros_s));
    lerParametros(par, m);

    Registro_s reg;
    int rrnAtual = 0;

    while (fread(&reg.removido, sizeof(char), 1, bin) == 1) {
        long int posInicio = ftell(bin) - 1;
        lerReg(bin, &reg);

        if (reg.removido == '0' && comparacoes(bin, reg, par, m - 1) == 0) {
            Cabecalho_s cab = lerCab(bin);
            reg.removido = '1';
            reg.proximo = cab.topo;
            cab.topo = rrnAtual;

            fseek(bin, posInicio, SEEK_SET);
            fwrite(&reg.removido, sizeof(char), 1, bin);
            fwrite(&reg.proximo, sizeof(int), 1, bin);
            escreverCab(cab, bin);
            fseek(bin, posInicio + 80, SEEK_SET);
        }

        liberarReg(&reg);
        rrnAtual++;
    }

    free(par);
    recalcularCabecalho(bin);
}

void insercao(FILE *bin) {
    int n;
    scanf(" %d", &n);

    Cabecalho_s cab = lerCab(bin);

    for (int i = 0; i < n; i++) {
        Registro_s reg;
        lerRegistroInsercao(&reg);

        if (cab.topo != -1) {
            int rrnInsercao = cab.topo;
            fseek(bin, 17 + rrnInsercao * 80 + 1, SEEK_SET);
            fread(&cab.topo, sizeof(int), 1, bin);
            fseek(bin, 17 + rrnInsercao * 80, SEEK_SET);
            escreverReg(bin, reg);
        } else {
            fseek(bin, 17 + cab.proxRRN * 80, SEEK_SET);
            escreverReg(bin, reg);
            cab.proxRRN++;
        }

        liberarReg(&reg);
    }

    escreverCab(cab, bin);
    recalcularCabecalho(bin);
}

void atualizacao(FILE *bin) {
    int n;
    scanf(" %d", &n);

    for (int i = 0; i < n; i++) {
        int m, p;
        scanf(" %d", &m);
        Parametros_s *buscaPar = (Parametros_s *) malloc((size_t) m * sizeof(Parametros_s));
        lerParametros(buscaPar, m);

        scanf(" %d", &p);
        Parametros_s *atualizaPar = (Parametros_s *) malloc((size_t) p * sizeof(Parametros_s));
        lerParametros(atualizaPar, p);

        fseek(bin, 17, SEEK_SET);

        Registro_s reg;
        while (fread(&reg.removido, sizeof(char), 1, bin) == 1) {
            long int posInicio = ftell(bin) - 1;
            lerReg(bin, &reg);

            if (reg.removido == '0' && comparacoes(bin, reg, buscaPar, m - 1) == 0) {
                aplicarAtualizacoes(&reg, atualizaPar, p);
                reg.removido = '0';
                reg.proximo = -1;
                fseek(bin, posInicio, SEEK_SET);
                escreverReg(bin, reg);
            }

            liberarReg(&reg);
        }

        free(buscaPar);
        free(atualizaPar);
    }

    recalcularCabecalho(bin);
}
